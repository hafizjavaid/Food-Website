-- MySQL dump 10.19  Distrib 10.3.28-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: faradjij_erp
-- ------------------------------------------------------
-- Server version	10.3.28-MariaDB-log-cll-lve

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `faradjij_erp`
--


--
-- Table structure for table `chats`
--

DROP TABLE IF EXISTS `chats`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `chats` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sender_id` int(11) unsigned DEFAULT NULL,
  `receiver_id` int(11) unsigned DEFAULT NULL,
  `message` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `status` tinytext COLLATE utf8_unicode_ci DEFAULT NULL,
  `replied` int(11) DEFAULT 0,
  `replied_for` int(11) DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `sender_id` (`sender_id`),
  KEY `receiver_id` (`receiver_id`),
  CONSTRAINT `chats_ibfk_3` FOREIGN KEY (`sender_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `chats_ibfk_4` FOREIGN KEY (`receiver_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chats`
--

LOCK TABLES `chats` WRITE;
/*!40000 ALTER TABLE `chats` DISABLE KEYS */;
INSERT INTO `chats` (`id`, `sender_id`, `receiver_id`, `message`, `status`, `replied`, `replied_for`, `created_at`, `updated_at`) VALUES (1,3,33,'Hello, Welcome, You have logged in for the first time and have\n                                        changed the password. simply go to the profile section and change your\n                                        password and other information. Thank You :) ',NULL,0,0,'2021-02-23 04:44:03','2021-02-23 04:44:03'),(2,3,34,'Hello, Welcome, You have logged in for the first time and have\n                                        changed the password. simply go to the profile section and change your\n                                        password and other information. Thank You :) ',NULL,0,0,'2021-02-25 17:20:45','2021-02-25 17:20:45'),(3,3,35,'Hello, Welcome, You have logged in for the first time and have\n                                        changed the password. simply go to the profile section and change your\n                                        password and other information. Thank You :) ',NULL,0,0,'2021-02-25 17:21:39','2021-02-25 17:21:39'),(4,3,36,'Hello, Welcome, You have logged in for the first time and have\n                                        changed the password. simply go to the profile section and change your\n                                        password and other information. Thank You :) ',NULL,0,0,'2021-03-10 16:36:52','2021-03-10 16:36:52');
/*!40000 ALTER TABLE `chats` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `consumables`
--

DROP TABLE IF EXISTS `consumables`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `consumables` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_by_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `approved` int(11) NOT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `deleted_by` int(11) DEFAULT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `code` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `serial` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image_url` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `main_category_id` int(11) NOT NULL,
  `sub_category_id` int(11) NOT NULL,
  `unit` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `quantity` int(11) NOT NULL,
  `min_quantity` int(11) NOT NULL DEFAULT 0,
  `max_quantity` int(11) NOT NULL DEFAULT 0,
  `state_id` int(11) NOT NULL,
  `brand_id` int(11) NOT NULL,
  `cost` int(11) NOT NULL,
  `price` int(11) NOT NULL,
  `purchase_detail` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `callibration` date DEFAULT NULL,
  `Authorize` tinyint(1) NOT NULL DEFAULT 0,
  `warranty` date DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `consumables`
--

LOCK TABLES `consumables` WRITE;
/*!40000 ALTER TABLE `consumables` DISABLE KEYS */;
INSERT INTO `consumables` (`id`, `status`, `created_by_type`, `approved`, `created_by`, `updated_by`, `deleted_by`, `name`, `type`, `code`, `serial`, `image_url`, `main_category_id`, `sub_category_id`, `unit`, `quantity`, `min_quantity`, `max_quantity`, `state_id`, `brand_id`, `cost`, `price`, `purchase_detail`, `description`, `callibration`, `Authorize`, `warranty`, `deleted_at`, `created_at`, `updated_at`) VALUES (3,'Approved','Admin',1,3,NULL,NULL,'Consumable tool 1','Tool','123as','1234532edq','https://www.brights.co.za/wp-content/uploads/2016/11/12934_Bosch-Circular-Saw-1400W-600x600.jpg',7,7,'pcs',23,20,88,5,8,0,0,NULL,'asdas',NULL,0,NULL,NULL,'2021-02-26 07:50:10','2021-02-26 07:50:10'),(4,'Approved','Admin',1,3,NULL,NULL,'New Con','Consumable','32412332123123','999999','https://image.shutterstock.com/image-photo/white-transparent-leaf-on-mirror-260nw-1029171697.jpg',7,7,'pcs',5,10,20,5,2,1000,1000,NULL,'asdasdsadsa asdas sadas asd',NULL,0,NULL,NULL,'2021-03-03 23:29:11','2021-03-04 00:40:02'),(5,'Approved','Admin',1,3,NULL,NULL,'Con Product','Consumable','66546456','444555','https://upload.wikimedia.org/wikipedia/commons/thumb/b/b6/Image_created_with_a_mobile_phone.png/1200px-Image_created_with_a_mobile_phone.png',3,4,'pcs',2,1,10,5,2,0,0,NULL,'aassadsdad',NULL,0,NULL,NULL,'2021-03-04 00:45:24','2021-03-04 00:45:24'),(6,'Approved','Admin',1,3,NULL,NULL,'Start Con','Consumable','8888888888','888888','https://upload.wikimedia.org/wikipedia/commons/thumb/b/b6/Image_created_with_a_mobile_phone.png/1200px-Image_created_with_a_mobile_phone.png',7,7,'pcs',2,1,10,5,2,0,0,NULL,'asdasdasd',NULL,0,NULL,NULL,'2021-03-04 01:34:34','2021-03-04 01:34:34');
/*!40000 ALTER TABLE `consumables` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `custom_users`
--

DROP TABLE IF EXISTS `custom_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `custom_users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_by_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `deleted_by` int(11) DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  `location_id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mobile_number` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `role_id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `custom_users`
--

LOCK TABLES `custom_users` WRITE;
/*!40000 ALTER TABLE `custom_users` DISABLE KEYS */;
INSERT INTO `custom_users` (`id`, `status`, `created_by_type`, `created_by`, `updated_by`, `deleted_by`, `user_id`, `location_id`, `mobile_number`, `role_id`, `deleted_at`, `created_at`, `updated_at`) VALUES (1,'Approved','Admin',3,NULL,NULL,3,'5','03242583439','Admin',NULL,NULL,NULL),(8,'Approved','Admin',3,3,NULL,24,'7','03011234567','Manager',NULL,'2020-12-31 00:47:51','2021-01-14 16:44:29'),(9,'Approved','Admin',3,3,NULL,25,'7','0796744157','Inventory clerk',NULL,'2021-01-01 04:19:50','2021-02-25 17:19:54'),(11,'Approved','Admin',3,NULL,NULL,27,'7','07002876329','Manager',NULL,'2021-01-05 08:27:31','2021-01-05 08:27:31'),(12,'Approved','Admin',3,NULL,NULL,28,'7','07002876323','Inventory clerk',NULL,'2021-01-05 08:29:34','2021-01-05 08:29:34'),(16,'Approved','Admin',3,3,NULL,32,'8','03011234567','Technician',NULL,'2021-01-13 14:57:13','2021-01-15 12:31:21'),(17,'Approved','Admin',3,NULL,NULL,33,'6','23456768979654','Manager',NULL,'2021-02-23 04:44:03','2021-02-23 04:44:03'),(18,'Approved','Admin',3,NULL,NULL,34,'7','+254708799961','Inventory clerk',NULL,'2021-02-25 17:20:45','2021-02-25 17:20:45'),(19,'Approved','Admin',3,NULL,NULL,35,'7','+254708799961','Inventory clerk',NULL,'2021-02-25 17:21:39','2021-02-25 17:21:39'),(20,'Approved','Admin',3,NULL,NULL,36,'7','03357481711','Admin',NULL,'2021-03-10 16:36:52','2021-03-10 16:36:52');
/*!40000 ALTER TABLE `custom_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customers`
--

DROP TABLE IF EXISTS `customers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `status` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_by_type` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `deleted_by` int(11) DEFAULT NULL,
  `name` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mobile_number` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customers`
--

LOCK TABLES `customers` WRITE;
/*!40000 ALTER TABLE `customers` DISABLE KEYS */;
INSERT INTO `customers` (`id`, `status`, `created_by_type`, `created_by`, `updated_by`, `deleted_by`, `name`, `email`, `mobile_number`, `description`, `deleted_at`, `created_at`, `updated_at`) VALUES (1,'Approved','Admin',3,3,NULL,'John the customer','soap@gmail.com','738428823','New client',NULL,'2021-01-14 04:22:45','2021-03-15 20:45:59'),(2,'Approved','Admin',3,3,NULL,'Murithi the customer','price@gmail.com','08485723382','New client',NULL,'2021-01-13 23:30:52','2021-03-15 20:46:42');
/*!40000 ALTER TABLE `customers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `failed_jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `failed_jobs`
--

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `group_chats`
--

DROP TABLE IF EXISTS `group_chats`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `group_chats` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sender_id` int(11) unsigned DEFAULT NULL,
  `message` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `sender_id` (`sender_id`),
  CONSTRAINT `group_chats_ibfk_2` FOREIGN KEY (`sender_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `group_chats`
--

LOCK TABLES `group_chats` WRITE;
/*!40000 ALTER TABLE `group_chats` DISABLE KEYS */;
INSERT INTO `group_chats` (`id`, `sender_id`, `message`, `created_at`, `updated_at`) VALUES (1,3,'hello','2021-02-13 14:28:10','2021-02-13 14:28:10');
/*!40000 ALTER TABLE `group_chats` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `job_cards`
--

DROP TABLE IF EXISTS `job_cards`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `job_cards` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=50 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `job_cards`
--

LOCK TABLES `job_cards` WRITE;
/*!40000 ALTER TABLE `job_cards` DISABLE KEYS */;
INSERT INTO `job_cards` (`id`, `code`, `deleted_at`, `created_at`, `updated_at`) VALUES (1,'01',NULL,'2020-12-22 14:37:16','2020-12-22 14:37:16'),(7,'02',NULL,'2021-01-05 05:29:59','2021-01-05 05:29:59'),(8,'03',NULL,'2021-01-05 08:46:27','2021-01-05 08:46:27'),(9,'04',NULL,'2021-01-05 21:48:45','2021-01-05 21:48:45'),(13,'05',NULL,'2021-01-05 22:08:19','2021-01-05 22:08:19'),(19,'06',NULL,'2021-01-06 15:56:04','2021-01-06 15:56:04'),(20,'07',NULL,'2021-01-08 14:45:32','2021-01-08 14:45:32'),(28,'08',NULL,'2021-01-09 17:59:46','2021-01-09 17:59:46'),(29,'09',NULL,'2021-01-09 18:32:46','2021-01-09 18:32:46'),(32,'11',NULL,'2021-01-09 19:49:16','2021-01-09 19:49:16'),(33,'012',NULL,'2021-01-11 13:47:12','2021-01-11 13:47:12'),(34,'013',NULL,'2021-01-15 12:52:19','2021-01-15 12:52:19'),(35,'014',NULL,'2021-01-20 16:29:56','2021-01-20 16:29:56'),(36,'015',NULL,'2021-01-25 20:07:21',NULL),(38,'016',NULL,'2021-01-25 16:20:41','2021-01-25 16:20:41'),(39,'017',NULL,'2021-02-14 19:01:45','2021-02-14 19:01:45'),(40,NULL,NULL,'2021-02-26 09:21:33','2021-02-26 09:21:33'),(43,'001',NULL,'2021-03-11 15:57:06','2021-03-11 15:57:06'),(44,'002',NULL,'2021-03-12 11:55:27','2021-03-12 11:55:27'),(45,'003',NULL,'2021-03-12 13:35:15','2021-03-12 13:35:15'),(46,'004',NULL,'2021-03-12 16:35:48','2021-03-12 16:35:48'),(47,'005',NULL,'2021-03-14 02:23:08','2021-03-14 02:23:08'),(48,'006',NULL,'2021-03-14 22:17:06','2021-03-14 22:17:06'),(49,'007',NULL,'2021-03-15 10:31:46','2021-03-15 10:31:46');
/*!40000 ALTER TABLE `job_cards` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `locations`
--

DROP TABLE IF EXISTS `locations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `locations` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_by_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `deleted_by` int(11) DEFAULT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `locations`
--

LOCK TABLES `locations` WRITE;
/*!40000 ALTER TABLE `locations` DISABLE KEYS */;
INSERT INTO `locations` (`id`, `status`, `created_by_type`, `created_by`, `updated_by`, `deleted_by`, `name`, `description`, `deleted_at`, `created_at`, `updated_at`) VALUES (7,'Approved','Admin',3,NULL,NULL,'HQ','Headquarter',NULL,'2020-12-31 04:04:37','2020-12-31 04:04:37'),(8,'Approved','Admin',3,NULL,NULL,'Kitengela House','Kitengela House',NULL,'2021-01-05 08:32:37','2021-01-05 08:32:37'),(9,'Approved','Admin',3,NULL,NULL,'Iko Briq Factory','Iko Briq Factory',NULL,'2021-01-05 08:32:57','2021-01-05 08:32:57'),(10,'Approved','Admin',3,NULL,NULL,'Kenapen Industries','Kenapen Industries',NULL,'2021-01-05 08:33:15','2021-01-05 08:33:15'),(11,'Approved','Admin',3,NULL,NULL,'KAPA Oil Refineries','KAPA Oil Refineries',NULL,'2021-01-05 08:33:35','2021-01-05 08:33:35');
/*!40000 ALTER TABLE `locations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `logs`
--

DROP TABLE IF EXISTS `logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `page_name` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `event` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `details` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=360 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `logs`
--

LOCK TABLES `logs` WRITE;
/*!40000 ALTER TABLE `logs` DISABLE KEYS */;
INSERT INTO `logs` (`id`, `user_id`, `page_name`, `event`, `details`, `created_at`) VALUES (13,3,'Users','Edit User',24,'2020-12-31 01:27:37'),(14,24,'Project','Add Project',2,'2020-12-31 01:32:38'),(15,24,'Project','Delete Project',2,'2020-12-31 01:34:06'),(16,3,'Project','Restore Project',2,'2020-12-31 01:34:53'),(17,24,'Tool State','Add Tool State',2,'2020-12-31 01:36:41'),(18,24,'Tool Brand','Add Tool Brand',2,'2020-12-31 01:37:02'),(19,3,'Main Category','Add Main Category',3,'2020-12-31 03:46:27'),(20,3,'Sub Category','Add Sub Category',3,'2020-12-31 03:47:07'),(21,3,'Tool Brand','Add Tool Brand',3,'2020-12-31 03:58:35'),(22,3,'Tool Brand','Delete Tool Brand',3,'2020-12-31 03:58:44'),(23,3,'Tool State','Add Tool State',3,'2020-12-31 04:00:44'),(24,3,'Tool State','Delete Tool State',3,'2020-12-31 04:00:55'),(25,3,'Location','Add Location',7,'2020-12-31 04:04:37'),(26,3,'Warehouse','Add Warehouse',6,'2020-12-31 04:05:10'),(27,3,'Warehouse','Edit Warehouse',6,'2020-12-31 04:05:33'),(28,3,'Tool State','Add Tool State',4,'2020-12-31 04:16:41'),(29,3,'Tool State','Add Tool State',5,'2020-12-31 04:16:54'),(30,3,'Tool Brand','Add Tool Brand',4,'2020-12-31 04:17:21'),(31,24,'tools','Add New Tool',3,'2020-12-31 04:20:22'),(32,24,'tools','Delete Tool',3,'2020-12-31 04:21:47'),(33,3,'tools','Restore Tool',3,'2020-12-31 04:22:10'),(34,24,'tools','Delete Tool',3,'2020-12-31 04:23:05'),(35,3,'tools','Add New Tool',4,'2020-12-31 04:24:16'),(36,3,'tools','Restore Tool',3,'2020-12-31 04:25:46'),(37,3,'tools','Delete Tool',3,'2020-12-31 04:28:00'),(38,3,'Sub Category','Add Sub Category',4,'2020-12-31 04:30:16'),(39,3,'tools','Add New Tool',5,'2020-12-31 04:32:54'),(40,3,'tools','Delete Tool',4,'2020-12-31 04:33:14'),(41,3,'Main Category','Add Main Category',4,'2021-01-01 02:56:48'),(42,3,'toolkit','Add Toolkit',15,'2021-01-01 03:44:36'),(43,3,'Users','Add User',9,'2021-01-01 04:19:50'),(44,3,'Users','Edit User',25,'2021-01-01 04:20:24'),(45,3,'tools','Add New Tool',6,'2021-01-02 06:32:52'),(46,3,'toolkit','Edit Toolkit',15,'2021-01-02 06:50:24'),(47,3,'Vendor','Add Vendor',1,'2021-01-05 05:20:07'),(48,3,'tools','Add New Tool',7,'2021-01-05 08:20:28'),(49,3,'Users','Add User',10,'2021-01-05 08:26:47'),(50,3,'Users','Add User',11,'2021-01-05 08:27:31'),(51,3,'Users','Add User',12,'2021-01-05 08:29:34'),(52,3,'Project','Add Project',3,'2021-01-05 08:30:39'),(53,3,'Project','Add Project',4,'2021-01-05 08:30:55'),(54,3,'Project','Add Project',5,'2021-01-05 08:31:09'),(55,3,'Project','Delete Project',2,'2021-01-05 08:31:20'),(56,3,'Project','Add Project',6,'2021-01-05 08:32:06'),(57,3,'Location','Add Location',8,'2021-01-05 08:32:37'),(58,3,'Location','Add Location',9,'2021-01-05 08:32:57'),(59,3,'Location','Add Location',10,'2021-01-05 08:33:15'),(60,3,'Location','Add Location',11,'2021-01-05 08:33:35'),(61,3,'Warehouse','Add Warehouse',7,'2021-01-05 08:34:11'),(62,3,'Warehouse','Add Warehouse',8,'2021-01-05 08:34:42'),(63,3,'Warehouse','Add Warehouse',9,'2021-01-05 08:35:21'),(64,3,'Main Category','Edit Main Category',2,'2021-01-05 08:36:00'),(65,3,'Main Category','Add Main Category',5,'2021-01-05 08:36:28'),(66,3,'Sub Category','Edit Sub Category',2,'2021-01-05 08:37:25'),(67,3,'Tool Brand','Edit Tool Brand',2,'2021-01-05 08:37:56'),(68,3,'Vendor','Add Vendor',2,'2021-01-05 08:45:05'),(69,3,'tools','Edit Tool',5,'2021-01-05 15:51:41'),(70,3,'tools','Add New Tool',8,'2021-01-05 16:42:00'),(71,3,'tools','Delete Tool',8,'2021-01-05 16:42:11'),(72,3,'Tool Brand','Add Tool Brand',5,'2021-01-05 17:09:11'),(73,3,'tools','Add New Tool',9,'2021-01-05 17:34:52'),(74,3,'tools','Add New Tool',10,'2021-01-05 17:37:57'),(75,3,'tools','Add New Tool',11,'2021-01-05 17:43:20'),(76,3,'tools','Add New Tool',12,'2021-01-05 17:44:32'),(77,3,'tools','Add New Tool',13,'2021-01-05 17:46:45'),(78,3,'tools','Add New Tool',14,'2021-01-05 17:48:02'),(79,3,'tools','Add New Tool',15,'2021-01-05 17:49:14'),(80,3,'tools','Add New Tool',16,'2021-01-05 17:51:29'),(81,3,'tools','Add New Tool',17,'2021-01-05 17:59:15'),(82,3,'tools','Delete Tool',17,'2021-01-05 18:01:31'),(83,3,'tools','Add New Tool',18,'2021-01-05 18:05:50'),(84,3,'tools','Add New Tool',19,'2021-01-05 18:08:08'),(85,3,'tools','Add New Tool',20,'2021-01-05 18:11:02'),(86,3,'tools','Add New Tool',21,'2021-01-05 18:20:08'),(87,3,'tools','Add New Tool',22,'2021-01-05 18:49:13'),(88,3,'tools','Add New Tool',23,'2021-01-05 18:49:19'),(89,3,'tools','Add New Tool',24,'2021-01-05 18:51:15'),(90,3,'tools','Add New Tool',25,'2021-01-05 18:53:01'),(91,3,'tools','Add New Tool',26,'2021-01-05 18:54:52'),(92,3,'tools','Add New Tool',27,'2021-01-05 18:56:17'),(93,3,'tools','Add New Tool',28,'2021-01-05 19:47:03'),(94,3,'tools','Add New Tool',29,'2021-01-05 19:49:47'),(95,3,'tools','Add New Tool',30,'2021-01-05 19:52:01'),(96,3,'tools','Add New Tool',31,'2021-01-05 19:52:06'),(97,3,'tools','Add New Tool',32,'2021-01-05 19:53:56'),(98,3,'tools','Add New Tool',33,'2021-01-05 19:57:54'),(99,3,'tools','Add New Tool',34,'2021-01-05 20:00:13'),(100,3,'tools','Add New Tool',35,'2021-01-05 20:01:35'),(101,3,'tools','Add New Tool',36,'2021-01-05 20:04:09'),(102,3,'tools','Add New Tool',37,'2021-01-05 20:05:52'),(103,3,'tools','Add New Tool',38,'2021-01-05 20:08:01'),(104,3,'tools','Add New Tool',39,'2021-01-05 21:40:18'),(105,3,'tools','Add New Tool',40,'2021-01-05 21:43:09'),(106,3,'tools','Add New Tool',41,'2021-01-05 21:44:42'),(107,3,'tools','Add New Tool',42,'2021-01-05 22:17:05'),(108,3,'tools','Add New Tool',43,'2021-01-06 14:13:00'),(109,3,'tools','Add New Tool',44,'2021-01-06 16:31:41'),(110,3,'tools','Add New Tool',45,'2021-01-06 16:49:33'),(111,3,'tools','Add New Tool',46,'2021-01-06 16:49:47'),(112,3,'tools','Add New Tool',47,'2021-01-06 16:55:16'),(113,3,'tools','Add New Tool',48,'2021-01-06 16:59:30'),(114,3,'tools','Add New Tool',49,'2021-01-06 17:06:02'),(115,3,'tools','Add New Tool',50,'2021-01-06 17:08:22'),(116,3,'tools','Add New Tool',51,'2021-01-06 17:14:18'),(117,3,'tools','Add New Tool',52,'2021-01-06 17:15:55'),(118,3,'tools','Add New Tool',53,'2021-01-06 17:17:52'),(119,3,'tools','Add New Tool',54,'2021-01-06 17:19:25'),(120,3,'tools','Add New Tool',55,'2021-01-06 17:24:54'),(121,3,'tools','Add New Tool',56,'2021-01-06 17:42:36'),(122,3,'tools','Add New Tool',57,'2021-01-06 17:45:32'),(123,3,'tools','Add New Tool',58,'2021-01-06 17:48:04'),(124,3,'tools','Add New Tool',59,'2021-01-06 17:49:16'),(125,3,'tools','Add New Tool',60,'2021-01-06 17:52:41'),(126,3,'Users','Add User',13,'2021-01-07 13:49:16'),(127,24,'tools','Edit Tool',42,'2021-01-09 18:25:50'),(128,3,'tools','Add New Tool',61,'2021-01-09 18:27:20'),(129,3,'tools','Edit Tool',5,'2021-01-09 19:38:29'),(130,3,'Consumables','Add New Consumable',1,'2021-01-11 12:45:00'),(131,3,'Users','Delete User',29,'2021-01-12 14:58:16'),(132,3,'Users','Add User',14,'2021-01-12 15:47:05'),(133,3,'Users','Edit User',30,'2021-01-12 15:55:00'),(134,3,'Users','Edit User',30,'2021-01-12 18:24:34'),(135,3,'Users','Edit User',30,'2021-01-12 18:25:24'),(136,3,'Users','Edit User',30,'2021-01-13 14:10:54'),(137,3,'Users','Delete User',30,'2021-01-13 14:51:14'),(138,3,'Users','Add User',15,'2021-01-13 14:51:32'),(139,3,'Users','Delete User',31,'2021-01-13 14:56:47'),(140,3,'Users','Add User',16,'2021-01-13 14:57:13'),(141,3,'toolkit','Edit Toolkit',15,'2021-01-13 15:28:50'),(142,3,'toolkit','Add Toolkit',29,'2021-01-13 15:31:12'),(143,3,'toolkit','Add Toolkit',30,'2021-01-13 15:33:49'),(144,3,'toolkit','Edit Toolkit',30,'2021-01-13 15:34:04'),(145,3,'toolkit','Add Toolkit',31,'2021-01-13 15:36:28'),(146,3,'toolkit','Add Toolkit',32,'2021-01-13 15:39:38'),(147,3,'toolkit','Add Toolkit',33,'2021-01-13 15:42:54'),(148,3,'toolkit','Add Toolkit',34,'2021-01-13 15:45:10'),(149,3,'toolkit','Add Toolkit',35,'2021-01-13 15:47:06'),(150,3,'toolkit','Add Toolkit',36,'2021-01-13 15:49:38'),(151,3,'toolkit','Add Toolkit',37,'2021-01-13 15:55:14'),(152,3,'toolkit','Delete Toolkit',37,'2021-01-13 15:55:21'),(153,3,'toolkit','Add Toolkit',38,'2021-01-13 15:56:42'),(154,3,'Users','Edit User',32,'2021-01-13 21:16:02'),(155,3,'Customer','Add Customer',2,'2021-01-13 23:30:53'),(156,3,'Customer','Edit Customer',2,'2021-01-13 23:34:02'),(157,3,'Users','Edit User',24,'2021-01-14 16:10:28'),(158,3,'Users','Edit User',24,'2021-01-14 16:11:17'),(159,3,'Users','Edit User',24,'2021-01-14 16:11:39'),(160,3,'Users','Edit User',24,'2021-01-14 16:11:52'),(161,3,'Users','Edit User',24,'2021-01-14 16:11:55'),(162,3,'Vendor','Edit Vendor',1,'2021-01-14 16:22:43'),(163,3,'Vendor','Edit Vendor',1,'2021-01-14 16:24:29'),(164,3,'Users','Edit User',24,'2021-01-14 16:44:32'),(165,3,'Tool State','Edit Tool State',4,'2021-01-14 17:12:22'),(166,3,'Tool Brand','Edit Tool Brand',2,'2021-01-14 17:13:25'),(167,3,'Sub Category','Edit Sub Category',3,'2021-01-14 17:14:38'),(168,3,'Warehouse','Edit Warehouse',5,'2021-01-14 17:27:23'),(169,3,'Warehouse','Edit Warehouse',4,'2021-01-14 17:27:38'),(170,3,'Location','Edit Location',5,'2021-01-14 17:30:29'),(171,3,'Project','Edit Project',4,'2021-01-14 17:43:07'),(172,3,'Vendor','Edit Vendor',2,'2021-01-14 17:46:09'),(173,3,'Customer','Edit Customer',2,'2021-01-14 18:02:28'),(174,3,'toolkit','Edit Toolkit',16,'2021-01-14 18:13:48'),(175,3,'toolkit','Edit Toolkit',16,'2021-01-14 18:14:09'),(176,3,'toolkit','Edit Toolkit',16,'2021-01-14 18:14:25'),(177,3,'Users','Edit User',32,'2021-01-14 18:44:22'),(178,3,'Users','Edit User',32,'2021-01-15 12:31:34'),(179,3,'Project','Edit Project',3,'2021-01-16 18:10:56'),(180,3,'Project','Edit Project',3,'2021-01-16 18:13:31'),(181,3,'Project','Edit Project',3,'2021-01-16 18:14:04'),(182,3,'toolkit','Edit Toolkit',38,'2021-01-16 21:03:02'),(183,3,'Users','Add User',17,'2021-01-21 12:38:58'),(184,3,'Users','Add User',18,'2021-01-21 12:40:21'),(185,3,'Users','Delete User',34,'2021-01-21 12:40:36'),(186,3,'Users','Delete User',33,'2021-01-21 12:42:34'),(187,3,'Users','Add User',19,'2021-01-21 13:02:04'),(188,3,'Main Category','Add Main Category',6,'2021-01-27 17:38:55'),(189,3,'Main Category','Add Main Category',7,'2021-01-27 17:46:30'),(190,3,'Main Category','Add Main Category',8,'2021-01-27 17:51:04'),(191,3,'Tool Brand','Add Tool Brand',6,'2021-01-27 17:55:44'),(192,3,'Tool Brand','Add Tool Brand',7,'2021-01-27 17:58:10'),(193,3,'Main Category','Add Main Category',9,'2021-01-27 20:39:28'),(194,3,'tools','Add New Tool',62,'2021-01-28 10:50:56'),(195,3,'Customer','Add Customer',3,'2021-01-28 11:08:48'),(196,3,'Customer','Add Customer',4,'2021-01-28 11:11:18'),(197,3,'Vendor','Add Vendor',3,'2021-01-28 11:17:23'),(198,3,'Customer','Add Customer',5,'2021-01-28 11:23:35'),(199,3,'Vendor','Add Vendor',4,'2021-01-28 16:12:26'),(200,3,'Customer','Add Customer',6,'2021-01-28 16:13:07'),(201,3,'Vendor','Add Vendor',5,'2021-01-28 16:40:17'),(202,3,'Sub Category','Add Sub Category',5,'2021-01-28 20:13:44'),(203,3,'Sub Category','Add Sub Category',6,'2021-01-28 20:14:53'),(204,3,'Sub Category','Add Sub Category',7,'2021-01-28 20:17:18'),(205,3,'Sub Category','Add Sub Category',8,'2021-01-28 20:19:20'),(206,3,'tools','Add New Tool',63,'2021-01-30 11:56:45'),(207,3,'Sub Category','Add Sub Category',5,'2021-02-12 20:59:00'),(208,3,'tools','Add New Tool',64,'2021-02-12 20:59:50'),(209,3,'tools','Add New Tool',65,'2021-02-13 10:22:19'),(210,3,'tools','Add New Tool',66,'2021-02-13 13:12:36'),(211,3,'tools','Add New Tool',67,'2021-02-13 21:59:16'),(212,3,'toolkit','Add Toolkit',39,'2021-02-15 18:47:38'),(213,3,'toolkit','Add Toolkit',40,'2021-02-15 19:46:41'),(214,3,'toolkit','Add Toolkit',41,'2021-02-15 20:13:45'),(215,3,'toolkit','Add Toolkit',42,'2021-02-15 20:13:54'),(216,3,'toolkit','Add Toolkit',43,'2021-02-15 20:14:09'),(217,3,'toolkit','Add Toolkit',44,'2021-02-15 20:21:00'),(218,3,'toolkit','Add Toolkit',45,'2021-02-15 20:35:52'),(219,3,'toolkit','Add Toolkit',46,'2021-02-15 20:55:19'),(220,3,'tools','Add New Tool',68,'2021-02-15 21:08:43'),(221,3,'Main Category','Add Main Category',6,'2021-02-23 00:24:17'),(222,3,'Sub Category','Add Sub Category',6,'2021-02-23 00:24:52'),(223,3,'tools','Add New Tool',69,'2021-02-23 00:27:23'),(224,3,'toolkit','Add Toolkit',47,'2021-02-23 00:38:59'),(225,3,'Users','Add User',17,'2021-02-23 04:44:03'),(226,3,'Main Category','Add Main Category',7,'2021-02-23 06:27:19'),(227,3,'Sub Category','Add Sub Category',7,'2021-02-23 06:27:37'),(228,3,'Tool Brand','Add Tool Brand',8,'2021-02-23 06:28:05'),(229,3,'Consumables','Add New Consumable',2,'2021-02-23 07:08:57'),(230,3,'Consumables','Add New Consumable',3,'2021-02-23 07:18:18'),(231,3,'Consumables','Add New Consumable',4,'2021-02-23 07:21:47'),(232,3,'Consumables','Add New Consumable',5,'2021-02-23 07:23:22'),(233,3,'Consumables','Add New Consumable',6,'2021-02-23 07:24:39'),(234,3,'Consumables','Add New Consumable',7,'2021-02-23 07:32:54'),(235,3,'tools','Add New Tool',70,'2021-02-23 07:34:10'),(236,3,'toolkit','Add Toolkit',48,'2021-02-23 09:31:10'),(237,3,'toolkit','Edit Toolkit',15,'2021-02-23 09:32:24'),(238,3,'toolkit','Add Toolkit',49,'2021-02-23 09:35:37'),(239,3,'toolkit','Add Toolkit',50,'2021-02-23 09:39:00'),(240,3,'toolkit','Edit Toolkit',15,'2021-02-23 09:41:38'),(241,3,'toolkit','Add Toolkit',51,'2021-02-23 09:45:53'),(242,3,'toolkit','Add Toolkit',52,'2021-02-23 09:47:27'),(243,3,'toolkit','Add Toolkit',53,'2021-02-23 10:03:52'),(244,3,'toolkit','Edit Toolkit',15,'2021-02-23 10:32:12'),(245,3,'toolkit','Add Toolkit',54,'2021-02-23 10:33:38'),(246,3,'toolkit','Add Toolkit',55,'2021-02-23 10:44:48'),(247,3,'Vendor','Add Vendor',6,'2021-02-23 10:47:25'),(248,3,'toolkit','Add Toolkit',56,'2021-02-23 11:33:17'),(249,3,'toolkit','Add Toolkit',57,'2021-02-23 11:33:58'),(250,3,'toolkit','Add Toolkit',58,'2021-02-23 11:34:18'),(251,3,'toolkit','Add Toolkit',59,'2021-02-23 12:15:47'),(252,3,'toolkit','Edit Toolkit',15,'2021-02-23 12:37:31'),(253,3,'toolkit','Edit Toolkit',39,'2021-02-23 12:38:00'),(254,3,'toolkit','Add Toolkit',60,'2021-02-23 17:52:09'),(255,3,'toolkit','Add Toolkit',61,'2021-02-24 04:21:10'),(256,3,'Consumables','Add New Consumable',8,'2021-02-24 05:37:19'),(257,3,'Consumables','Add New Consumable',9,'2021-02-24 06:21:03'),(258,3,'tools','Add New Tool',1,'2021-02-24 06:59:10'),(259,3,'tools','Add New Tool',2,'2021-02-24 06:59:55'),(260,3,'Consumables','Add New Consumable',10,'2021-02-24 07:01:33'),(261,3,'Consumables','Add New Consumable',11,'2021-02-24 07:02:29'),(262,3,'Consumables','Add New Consumable',12,'2021-02-24 08:10:39'),(263,3,'Consumables','Add New Consumable',13,'2021-02-24 08:17:51'),(264,3,'Consumables','Edit Consumable',13,'2021-02-24 08:22:09'),(265,3,'tools','Add New Tool',3,'2021-02-24 08:26:30'),(266,3,'tools','Add New Tool',4,'2021-02-24 08:31:52'),(267,3,'Consumables','Add New Consumable',1,'2021-02-24 08:45:15'),(268,3,'toolkit','Add Toolkit',1,'2021-02-24 08:47:14'),(269,3,'toolkit','Edit Toolkit',1,'2021-02-24 08:54:51'),(270,3,'toolkit','Add Toolkit',2,'2021-02-24 08:55:13'),(271,3,'tools','Add New Tool',5,'2021-02-24 09:23:38'),(272,3,'tools','Add New Tool',6,'2021-02-24 09:27:14'),(273,3,'Consumables','Add New Consumable',2,'2021-02-24 09:30:35'),(274,3,'tools','Add New Tool',7,'2021-02-24 12:38:47'),(275,3,'tools','Add New Tool',8,'2021-02-24 16:12:24'),(276,3,'tools','Add New Tool',9,'2021-02-24 16:32:50'),(277,3,'tools','Add New Tool',10,'2021-02-24 16:39:12'),(278,3,'tools','Add New Tool',11,'2021-02-24 16:40:44'),(279,3,'Sub Category','Add Sub Category',8,'2021-02-25 16:38:31'),(280,3,'Tool Brand','Add Tool Brand',9,'2021-02-25 16:39:18'),(281,3,'tools','Add New Tool',12,'2021-02-25 16:39:40'),(282,3,'Sub Category','Add Sub Category',9,'2021-02-25 16:42:55'),(283,3,'tools','Add New Tool',13,'2021-02-25 16:44:10'),(284,3,'toolkit','Add Toolkit',3,'2021-02-25 17:08:34'),(285,3,'Users','Delete User',26,'2021-02-25 17:20:17'),(286,3,'Users','Add User',18,'2021-02-25 17:20:45'),(287,3,'Users','Add User',19,'2021-02-25 17:21:39'),(288,3,'tools','Add New Tool',14,'2021-02-25 17:24:09'),(289,3,'tools','Add New Tool',15,'2021-02-25 17:29:09'),(290,3,'tools','Add New Tool',16,'2021-02-26 05:15:30'),(291,3,'tools','Add New Tool',17,'2021-02-26 06:19:56'),(292,3,'Consumables','Add New Consumable',3,'2021-02-26 07:50:10'),(293,3,'tools','Add New Tool',1,'2021-03-02 03:04:41'),(294,3,'tools','Edit Tool',1,'2021-03-02 09:44:46'),(295,3,'tools','Add New Tool',2,'2021-03-02 12:22:46'),(296,3,'tools','Add New Tool',3,'2021-03-02 12:45:19'),(297,3,'tools','Add New Tool',4,'2021-03-02 12:50:49'),(298,3,'tools','Add New Tool',5,'2021-03-02 22:15:20'),(299,3,'tools','Add New Tool',6,'2021-03-03 00:22:11'),(300,3,'Consumables','Add New Consumable',4,'2021-03-03 23:29:12'),(301,3,'Consumables','Add New Consumable',5,'2021-03-04 00:45:24'),(302,3,'Consumables','Add New Consumable',6,'2021-03-04 01:34:34'),(303,3,'Consumables','Add New Consumable',7,'2021-03-04 01:42:15'),(304,3,'tools','Add New Tool',8,'2021-03-04 01:51:38'),(305,3,'tools','Add New Tool',9,'2021-03-04 01:59:55'),(306,3,'tools','Add New Tool',10,'2021-03-04 07:03:53'),(307,3,'Consumable','Add New Consumable',11,'2021-03-04 07:18:01'),(308,3,'Consumable','Add New Consumable',12,'2021-03-04 07:22:34'),(309,3,'Tool','Add New Tool',13,'2021-03-04 10:07:51'),(310,3,'Tool','Add New Tool',14,'2021-03-09 15:55:50'),(311,3,'Tool','Add New Tool',15,'2021-03-09 16:02:00'),(312,3,'Tool','Add New Tool',16,'2021-03-09 16:41:19'),(313,3,'Tool','Add New Tool',17,'2021-03-09 16:46:27'),(314,3,'Main Category','Add Main Category',8,'2021-03-10 15:54:17'),(315,3,'Sub Category','Add Sub Category',10,'2021-03-10 15:55:02'),(316,3,'Consumable','Add New Consumable',18,'2021-03-10 15:55:46'),(317,3,'Consumable','Add New Consumable',19,'2021-03-10 16:01:09'),(318,3,'Users','Add User',20,'2021-03-10 16:36:52'),(319,3,'Sub Category','Add Sub Category',11,'2021-03-12 11:18:44'),(320,3,'Consumable','Add New Consumable',20,'2021-03-12 11:19:44'),(321,3,'Tool','Add New Tool',21,'2021-03-12 11:32:33'),(322,3,'tools','Edit Tool',21,'2021-03-12 11:38:47'),(323,3,'Tool','Add New Tool',22,'2021-03-12 12:04:59'),(324,3,'Tool','Add New Tool',23,'2021-03-12 12:19:30'),(325,3,'Consumable','Add New Consumable',24,'2021-03-12 16:25:53'),(326,3,'Tool','Add New Tool',25,'2021-03-13 22:49:03'),(327,3,'Consumable','Add New Consumable',26,'2021-03-13 23:05:25'),(328,3,'Tool','Add New Tool',27,'2021-03-14 22:05:49'),(329,3,'Location','Delete Location',6,'2021-03-15 20:40:55'),(330,3,'Location','Delete Location',5,'2021-03-15 20:41:04'),(331,3,'Project','Delete Project',7,'2021-03-15 20:41:50'),(332,3,'Project','Delete Project',6,'2021-03-15 20:41:58'),(333,3,'Tool Brand','Delete Tool Brand',7,'2021-03-15 20:43:55'),(334,3,'Tool Brand','Delete Tool Brand',8,'2021-03-15 20:44:04'),(335,3,'Tool State','Delete Tool State',2,'2021-03-15 20:44:51'),(336,3,'Customer','Edit Customer',1,'2021-03-15 20:45:59'),(337,3,'Customer','Edit Customer',2,'2021-03-15 20:46:42'),(338,3,'Vendor','Edit Vendor',5,'2021-03-15 20:47:44'),(339,3,'Vendor','Edit Vendor',6,'2021-03-15 20:48:11'),(340,3,'Vendor','Edit Vendor',1,'2021-03-15 20:48:57'),(341,3,'Warehouse','Delete Warehouse',4,'2021-03-15 20:50:09'),(342,3,'Warehouse','Delete Warehouse',5,'2021-03-15 20:50:16'),(343,3,'Warehouse','Delete Warehouse',8,'2021-03-15 20:50:24'),(344,3,'Warehouse','Add Warehouse',10,'2021-03-15 20:50:57'),(345,3,'Warehouse','Add Warehouse',11,'2021-03-15 20:51:28'),(346,3,'Consumable','Add New Consumable',1,'2021-03-15 20:57:47'),(347,3,'Tool','Add New Tool',2,'2021-03-15 21:03:13'),(348,3,'Sub Category','Add Sub Category',12,'2021-03-15 21:08:58'),(349,3,'Tool','Add New Tool',3,'2021-03-15 21:09:46'),(350,3,'Tool','Add New Tool',1,'2021-03-16 11:00:33'),(351,3,'Tool','Add New Tool',2,'2021-03-17 23:31:05'),(352,3,'toolkit','Add Toolkit',1,'2021-03-17 23:39:42'),(353,3,'toolkit','Add Toolkit',2,'2021-03-17 23:43:18'),(354,3,'Tool Brand','Add Tool Brand',10,'2021-03-18 00:08:19'),(355,3,'Tool','Add New Tool',3,'2021-03-18 00:08:33'),(356,3,'Tool','Add New Tool',4,'2021-03-18 10:47:09'),(357,3,'Tool','Add New Tool',1,'2021-03-18 13:05:46'),(358,3,'Tool','Add New Tool',2,'2021-03-18 13:07:09'),(359,3,'toolkit','Add Toolkit',3,'2021-03-23 11:03:46');
/*!40000 ALTER TABLE `logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `main_categories`
--

DROP TABLE IF EXISTS `main_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `main_categories` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_by_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `deleted_by` int(11) DEFAULT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `main_categories`
--

LOCK TABLES `main_categories` WRITE;
/*!40000 ALTER TABLE `main_categories` DISABLE KEYS */;
INSERT INTO `main_categories` (`id`, `status`, `created_by_type`, `created_by`, `updated_by`, `deleted_by`, `name`, `description`, `deleted_at`, `created_at`, `updated_at`) VALUES (1,'Approved','Admin',NULL,NULL,20,'lorem','lorem','2020-12-30 21:58:56','2020-12-19 21:10:27','2020-12-30 21:58:56'),(2,'Approved','Admin',3,3,NULL,'Power Tools','None',NULL,'2020-12-31 00:52:17','2021-01-05 08:36:00'),(3,'Approved','Admin',3,NULL,NULL,'Hand Tool','Tool',NULL,'2020-12-31 03:46:27','2020-12-31 03:46:27'),(4,'Approved','Admin',3,NULL,NULL,'Impact Drill','Impact Drill',NULL,'2021-01-01 02:56:48','2021-01-01 02:56:48'),(5,'Approved','Admin',3,NULL,NULL,'Machines','machinery',NULL,'2021-01-05 08:36:28','2021-01-05 08:36:28'),(6,'Approved','Admin',3,NULL,NULL,'sawing tool','sawing tool',NULL,'2021-02-23 00:24:17','2021-02-23 00:24:17'),(7,'Approved','Admin',3,NULL,NULL,'demo','demo',NULL,'2021-02-23 06:27:19','2021-02-23 06:27:19'),(8,'Approved','Admin',3,NULL,NULL,'Consumables Main Category','Consumables',NULL,'2021-03-10 15:54:17','2021-03-10 15:54:17');
/*!40000 ALTER TABLE `main_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES (1,'2014_10_12_000000_create_users_table',1),(2,'2014_10_12_100000_create_password_resets_table',1),(3,'2019_08_19_000000_create_failed_jobs_table',1),(4,'2020_10_28_064339_create_projects_table',1),(5,'2020_10_29_040702_create_locations_table',1),(6,'2020_10_29_043325_create_warehouses_table',1),(7,'2020_10_29_063711_create_main_categories_table',1),(8,'2020_10_29_070250_create_sub_categories_table',1),(9,'2020_10_29_075947_create_toolstates_table',1),(10,'2020_10_29_084006_create_tool_brands_table',1),(11,'2020_10_29_103913_create_custom_users_table',1),(12,'2020_10_31_041831_create_tools_table',1);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notifications`
--

DROP TABLE IF EXISTS `notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `notifications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `notifiable_id` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `notifiable_type` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `data` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_read` tinyint(1) DEFAULT NULL,
  `read_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notifications`
--

LOCK TABLES `notifications` WRITE;
/*!40000 ALTER TABLE `notifications` DISABLE KEYS */;
INSERT INTO `notifications` (`id`, `type`, `notifiable_id`, `notifiable_type`, `data`, `is_read`, `read_at`, `created_at`, `updated_at`) VALUES (1,'Welcome','25',NULL,'Hello, Welcome, You have logged in for the first time and have changed the password.',1,NULL,'2021-01-01 04:19:50',NULL),(2,'Welcome','26',NULL,'Hello, Welcome, You have logged in for the first time and have changed the password.',1,NULL,'2021-01-05 08:26:47',NULL),(3,'Change Password','26',NULL,'Hello, You have changed the password.',1,NULL,'2021-01-05 08:26:47',NULL),(4,'Welcome','27',NULL,'Hello, Welcome, You have logged in for the first time and have changed the password.',0,NULL,'2021-01-05 08:27:31',NULL),(5,'Change Password','27',NULL,'Hello, You have changed the password.',0,NULL,'2021-01-05 08:27:31',NULL),(6,'Welcome','28',NULL,'Hello, Welcome, You have logged in for the first time and have changed the password.',0,NULL,'2021-01-05 08:29:34',NULL),(7,'Change Password','28',NULL,'Hello, You have changed the password.',0,NULL,'2021-01-05 08:29:34',NULL),(8,'Welcome','29',NULL,'Hello, Welcome, You have logged in for the first time and have changed the password.',1,NULL,'2021-01-07 13:49:15',NULL),(9,'Change Password','29',NULL,'Hello, You have changed the password.',1,NULL,'2021-01-07 13:49:15',NULL),(10,'Welcome','30',NULL,'Hello, Welcome, You have logged in for the first time and have changed the password.',1,NULL,'2021-01-12 15:47:05',NULL),(11,'Change Password','30',NULL,'Hello, You have changed the password.',1,NULL,'2021-01-12 15:47:05',NULL),(12,'Welcome','31',NULL,'Hello, Welcome, You have logged in for the first time and have changed the password.',1,NULL,'2021-01-13 14:51:32',NULL),(13,'Change Password','31',NULL,'Hello, You have changed the password.',1,NULL,'2021-01-13 14:51:32',NULL),(14,'Welcome','32',NULL,'Hello, Welcome, You have logged in for the first time and have changed the password.',1,NULL,'2021-01-13 14:57:13',NULL),(15,'Change Password','32',NULL,'Hello, You have changed the password.',1,NULL,'2021-01-13 14:57:13',NULL),(16,'Welcome','33',NULL,'Hello, Welcome, You have logged in for the first time and have changed the password.',1,NULL,'2021-01-21 12:38:58',NULL),(17,'Change Password','33',NULL,'Hello, You have changed the password.',1,NULL,'2021-01-21 12:38:58',NULL),(18,'Welcome','34',NULL,'Hello, Welcome, You have logged in for the first time and have changed the password.',0,NULL,'2021-01-21 12:40:21',NULL),(19,'Change Password','34',NULL,'Hello, You have changed the password.',0,NULL,'2021-01-21 12:40:21',NULL),(20,'Welcome','35',NULL,'Hello, Welcome, You have logged in for the first time and have changed the password.',0,NULL,'2021-01-21 13:02:03',NULL),(21,'Change Password','35',NULL,'Hello, You have changed the password.',0,NULL,'2021-01-21 13:02:03',NULL),(22,'Welcome','33',NULL,'Hello, Welcome, You have logged in for the first time and have changed the password.',0,NULL,'2021-02-23 04:44:03',NULL),(23,'Change Password','33',NULL,'Hello, You have changed the password.',0,NULL,'2021-02-23 04:44:03',NULL),(24,'Welcome','34',NULL,'Hello, Welcome, You have logged in for the first time and have changed the password.',0,NULL,'2021-02-25 17:20:45',NULL),(25,'Change Password','34',NULL,'Hello, You have changed the password.',0,NULL,'2021-02-25 17:20:45',NULL),(26,'Welcome','35',NULL,'Hello, Welcome, You have logged in for the first time and have changed the password.',0,NULL,'2021-02-25 17:21:39',NULL),(27,'Change Password','35',NULL,'Hello, You have changed the password.',0,NULL,'2021-02-25 17:21:39',NULL),(28,'Welcome','36',NULL,'Hello, Welcome, You have logged in for the first time and have changed the password.',0,NULL,'2021-03-10 16:36:52',NULL),(29,'Change Password','36',NULL,'Hello, You have changed the password.',0,NULL,'2021-03-10 16:36:52',NULL);
/*!40000 ALTER TABLE `notifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_resets`
--

DROP TABLE IF EXISTS `password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_resets`
--

LOCK TABLES `password_resets` WRITE;
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
INSERT INTO `password_resets` (`email`, `token`, `created_at`) VALUES ('nomanasifali2016@gmail.com','$2y$10$SXhrzP/RxiROC4DZdUs2H.v1ZJFH3HgOscP/VvYu2b6/pvHnwfD.C','2021-02-12 19:42:49'),('umarzahid028@gmail.com','$2y$10$7I/.aUPPR4VM0oZynBmEeu9fbeN8Ch/XIFpfaswtpzEpE8qu8iHTK','2021-02-23 04:51:31');
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `projects`
--

DROP TABLE IF EXISTS `projects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `projects` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_by_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `deleted_by` int(11) DEFAULT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_close` int(1) DEFAULT NULL,
  `reopen_date` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `projects`
--

LOCK TABLES `projects` WRITE;
/*!40000 ALTER TABLE `projects` DISABLE KEYS */;
INSERT INTO `projects` (`id`, `status`, `created_by_type`, `created_by`, `updated_by`, `deleted_by`, `name`, `description`, `is_close`, `reopen_date`, `deleted_at`, `created_at`, `updated_at`) VALUES (3,'Approved','Admin',3,3,NULL,'Kenapen Smart Metering','Kenapen Smart Metering',0,'2021-01-18 02:00:00',NULL,'2021-01-05 08:30:39','2021-01-16 18:14:04'),(4,'Approved','Admin',3,3,NULL,'Kitengela House Project','Kitengela House Project',0,NULL,NULL,'2021-01-05 08:30:55','2021-01-14 17:43:07'),(5,'Approved','Admin',3,NULL,NULL,'KAPA Maxeff Demo','KAPA Maxeff Demo',0,NULL,NULL,'2021-01-05 08:31:09','2021-01-05 08:31:09');
/*!40000 ALTER TABLE `projects` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sourcebin`
--

DROP TABLE IF EXISTS `sourcebin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sourcebin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sourcebin`
--

LOCK TABLES `sourcebin` WRITE;
/*!40000 ALTER TABLE `sourcebin` DISABLE KEYS */;
INSERT INTO `sourcebin` (`id`, `name`, `created_at`, `updated_at`, `deleted_at`) VALUES (2,'Top Shelf','2021-03-10 16:08:04','0000-00-00 00:00:00',NULL),(3,'Top Shelf','2021-03-10 16:08:10','0000-00-00 00:00:00',NULL),(4,'Bottom Shelf','2021-03-12 11:35:59','2021-03-12 11:35:59',NULL),(5,'On Wall board','2021-03-18 10:50:41','2021-03-18 10:50:41',NULL);
/*!40000 ALTER TABLE `sourcebin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stock_in_serialno`
--

DROP TABLE IF EXISTS `stock_in_serialno`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `stock_in_serialno` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tool_id` int(11) NOT NULL,
  `start_serial_no` bigint(20) NOT NULL,
  `serial_no` bigint(20) NOT NULL,
  `stock_in_id` bigint(20) NOT NULL,
  `state` enum('transfer','stockout') DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stock_in_serialno`
--

LOCK TABLES `stock_in_serialno` WRITE;
/*!40000 ALTER TABLE `stock_in_serialno` DISABLE KEYS */;
INSERT INTO `stock_in_serialno` (`id`, `tool_id`, `start_serial_no`, `serial_no`, `stock_in_id`, `state`, `created_at`, `updated_at`) VALUES (1,1,0,1000,0,NULL,'2021-03-18 13:05:46','2021-03-18 13:05:46'),(2,2,0,2000,0,NULL,'2021-03-18 13:07:09','2021-03-18 13:07:09');
/*!40000 ALTER TABLE `stock_in_serialno` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stock_ins`
--

DROP TABLE IF EXISTS `stock_ins`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `stock_ins` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Pending',
  `tool_id` int(11) NOT NULL,
  `tool_name` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `qty` double NOT NULL DEFAULT 0,
  `type` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `serial_no` int(20) NOT NULL,
  `stockin_qty` int(11) NOT NULL DEFAULT 0,
  `created_by_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `deleted_by` int(11) DEFAULT NULL,
  `officer_id` int(11) DEFAULT NULL,
  `responsible_id` int(11) DEFAULT NULL,
  `toolkit_id` int(11) DEFAULT NULL,
  `source_bin` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `vendor_id` int(11) DEFAULT NULL,
  `stocked_in_by_user_type` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `dest_warehouse_id` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `memo` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `job_card_id` int(11) unsigned DEFAULT NULL,
  `site` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `start_mileage` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `stop_mileage` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `vehicle` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bring_type` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bringing_person_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `invoice` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `lpo` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `delivery_note` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `document_file` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `no_of_tools` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `serial` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `approved` int(11) DEFAULT NULL,
  `reason` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stock_ins`
--

LOCK TABLES `stock_ins` WRITE;
/*!40000 ALTER TABLE `stock_ins` DISABLE KEYS */;
/*!40000 ALTER TABLE `stock_ins` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stock_out_toolkits`
--

DROP TABLE IF EXISTS `stock_out_toolkits`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `stock_out_toolkits` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT 'Pending',
  `officer_id` int(11) DEFAULT NULL,
  `responsible_id` int(11) DEFAULT NULL,
  `created_by_type` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `deleted_by` int(11) DEFAULT NULL,
  `stock_out_qty` int(11) DEFAULT NULL,
  `no_of_tools` int(11) DEFAULT NULL,
  `tools_used` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `stock_out_to_type` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `stockout_toolkit_by_user_type` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `stock_out_to` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `memo` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `job_card_id` int(11) DEFAULT NULL,
  `project_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `location_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `start_mileage` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `stop_mileage` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `vehicle` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `toolkit_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `stocked_out_tools_by_user_type` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `approved` tinyint(4) DEFAULT 0,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stock_out_toolkits`
--

LOCK TABLES `stock_out_toolkits` WRITE;
/*!40000 ALTER TABLE `stock_out_toolkits` DISABLE KEYS */;
/*!40000 ALTER TABLE `stock_out_toolkits` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stocked_tools`
--

DROP TABLE IF EXISTS `stocked_tools`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `stocked_tools` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tool_id` int(11) DEFAULT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `source_bin` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `source_warehouse` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `dest_warehouse_id` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `dest_project_id` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `initial_source_house` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `deleted_by` int(11) DEFAULT NULL,
  `toolkit_id` int(11) DEFAULT NULL,
  `stockin_id` int(11) DEFAULT NULL,
  `stockout_id` int(11) DEFAULT NULL,
  `transfer_id` int(11) DEFAULT NULL,
  `qty` int(11) DEFAULT NULL,
  `tool_price` int(11) DEFAULT NULL,
  `cost_price` int(11) NOT NULL,
  `callibration` date DEFAULT NULL,
  `warranty` date DEFAULT NULL,
  `start_mileage` double DEFAULT NULL,
  `stop_mileage` double DEFAULT NULL,
  `transfer_qty` int(11) DEFAULT NULL,
  `stock_out_qty` int(11) DEFAULT NULL,
  `stocked_tools_by_user_type` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `transfer_tools_by_user_type` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `stocked_out_tools_by_user_type` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `stock_out_comments` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `expected_from_stockout` date DEFAULT NULL,
  `approved` tinyint(4) DEFAULT 0,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stocked_tools`
--

LOCK TABLES `stocked_tools` WRITE;
/*!40000 ALTER TABLE `stocked_tools` DISABLE KEYS */;
/*!40000 ALTER TABLE `stocked_tools` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stockin_serial`
--

DROP TABLE IF EXISTS `stockin_serial`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `stockin_serial` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tool_id` int(11) NOT NULL,
  `start_serial_no` bigint(20) NOT NULL,
  `serial_no` bigint(20) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stockin_serial`
--

LOCK TABLES `stockin_serial` WRITE;
/*!40000 ALTER TABLE `stockin_serial` DISABLE KEYS */;
INSERT INTO `stockin_serial` (`id`, `tool_id`, `start_serial_no`, `serial_no`, `created_at`, `updated_at`) VALUES (5,1,1000,1010,'2021-03-02 03:04:41','2021-03-17 20:58:09'),(6,2,2000,2006,'2021-03-02 12:22:46','2021-03-17 23:33:15'),(7,3,3000,3004,'2021-03-02 12:45:19','2021-03-15 23:17:20'),(8,4,4000,4004,'2021-03-02 12:50:49','2021-03-18 10:50:41'),(9,5,5000,5001,'2021-03-02 22:15:20','2021-03-02 22:20:12'),(10,6,6000,6001,'2021-03-03 00:22:11','2021-03-04 01:23:58'),(11,8,7000,7001,'2021-03-04 01:51:38','2021-03-04 01:52:31'),(12,9,8000,8002,'2021-03-04 01:59:55','2021-03-04 09:27:53'),(13,10,9000,9000,'2021-03-04 07:03:53','2021-03-04 07:03:53'),(14,11,10000,10001,'2021-03-04 07:18:01','2021-03-04 07:19:42'),(15,12,11000,11001,'2021-03-04 07:22:34','2021-03-04 07:35:41'),(16,13,12000,12003,'2021-03-04 10:07:51','2021-03-09 15:41:37'),(17,14,13000,13001,'2021-03-09 15:55:50','2021-03-09 16:28:27'),(18,15,14000,14001,'2021-03-09 16:02:00','2021-03-09 16:28:27'),(19,16,15000,15001,'2021-03-09 16:41:19','2021-03-09 16:50:39'),(20,17,16000,16001,'2021-03-09 16:46:27','2021-03-09 16:50:39'),(21,18,17000,17003,'2021-03-10 15:55:46','2021-03-10 16:12:35'),(22,19,18000,18001,'2021-03-10 16:01:09','2021-03-10 16:12:35'),(23,20,19000,19000,'2021-03-12 11:19:44','2021-03-12 11:19:44'),(24,21,20000,20002,'2021-03-12 11:32:33','2021-03-12 12:09:22'),(25,22,21000,21000,'2021-03-12 12:04:59','2021-03-12 12:04:59'),(26,23,22000,22001,'2021-03-12 12:19:30','2021-03-12 12:22:05'),(27,24,23000,23001,'2021-03-12 16:25:53','2021-03-12 16:29:14'),(28,25,24000,24001,'2021-03-13 22:49:03','2021-03-13 22:51:13'),(29,26,25000,25001,'2021-03-13 23:05:25','2021-03-13 23:13:12'),(30,27,26000,26001,'2021-03-14 22:05:49','2021-03-14 22:08:11'),(31,1,27000,27000,'2021-03-15 20:57:47','2021-03-15 20:57:47'),(32,2,28000,28000,'2021-03-15 21:03:13','2021-03-15 21:03:13'),(33,3,29000,29000,'2021-03-15 21:09:46','2021-03-15 21:09:46'),(34,1,30000,30000,'2021-03-16 11:00:33','2021-03-16 11:00:33'),(35,2,31000,31000,'2021-03-17 23:31:05','2021-03-17 23:31:05'),(36,3,32000,32000,'2021-03-18 00:08:33','2021-03-18 00:08:33'),(37,4,33000,33000,'2021-03-18 10:47:09','2021-03-18 10:47:09'),(38,1,34000,34000,'2021-03-18 13:05:46','2021-03-18 13:05:46'),(39,2,35000,35000,'2021-03-18 13:07:09','2021-03-18 13:07:09');
/*!40000 ALTER TABLE `stockin_serial` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sub_categories`
--

DROP TABLE IF EXISTS `sub_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sub_categories` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_by_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `deleted_by` int(11) DEFAULT NULL,
  `maincategory_id` int(11) NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sub_categories`
--

LOCK TABLES `sub_categories` WRITE;
/*!40000 ALTER TABLE `sub_categories` DISABLE KEYS */;
INSERT INTO `sub_categories` (`id`, `status`, `created_by_type`, `created_by`, `updated_by`, `deleted_by`, `maincategory_id`, `name`, `description`, `deleted_at`, `created_at`, `updated_at`) VALUES (2,'Approved','Admin',3,3,NULL,4,'Impact Drill','impact drill mach',NULL,'2020-12-31 00:54:39','2021-01-05 08:37:25'),(3,'Approved','Admin',3,3,NULL,3,'Heatgun','Heatgun',NULL,'2020-12-31 03:47:07','2021-01-14 17:14:38'),(4,'Approved','Admin',3,NULL,NULL,3,'Circular Saw','Circular Saw',NULL,'2020-12-31 04:30:16','2020-12-31 04:30:16'),(5,'Approved','Admin',3,NULL,NULL,2,'Power','test',NULL,'2021-02-12 20:58:59','2021-02-12 20:58:59'),(6,'Approved','Admin',3,NULL,NULL,6,'sub sawing tool','sub sawing tool',NULL,'2021-02-23 00:24:52','2021-02-23 00:24:52'),(7,'Approved','Admin',3,NULL,NULL,7,'demo 1','demo 1',NULL,'2021-02-23 06:27:37','2021-02-23 06:27:37'),(8,'Approved','Admin',3,NULL,NULL,2,'grinding tools','Grinders',NULL,'2021-02-25 16:38:31','2021-02-25 16:38:31'),(9,'Approved','Admin',3,NULL,NULL,2,'Sawing Tools','Sawing Tools',NULL,'2021-02-25 16:42:55','2021-02-25 16:42:55'),(10,'Approved','Admin',3,NULL,NULL,8,'Consumables Discs','Items',NULL,'2021-03-10 15:55:02','2021-03-10 15:55:02'),(11,'Approved','Admin',3,NULL,NULL,8,'Drill Bit Consumables','Bits',NULL,'2021-03-12 11:18:44','2021-03-12 11:18:44'),(12,'Approved','Admin',3,NULL,NULL,3,'Cutting Machines','New',NULL,'2021-03-15 21:08:58','2021-03-15 21:08:58');
/*!40000 ALTER TABLE `sub_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tool_brands`
--

DROP TABLE IF EXISTS `tool_brands`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tool_brands` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_by_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_by` int(11) unsigned DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `deleted_by` int(11) DEFAULT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `created_by` (`created_by`),
  CONSTRAINT `tool_brands_ibfk_1` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tool_brands`
--

LOCK TABLES `tool_brands` WRITE;
/*!40000 ALTER TABLE `tool_brands` DISABLE KEYS */;
INSERT INTO `tool_brands` (`id`, `status`, `created_by_type`, `created_by`, `updated_by`, `deleted_by`, `name`, `description`, `deleted_at`, `created_at`, `updated_at`) VALUES (1,'Approved','Admin',3,NULL,20,'brand','lorem ipsum dolar sit amet','2020-12-30 22:00:38','2020-12-19 16:15:48','2020-12-30 22:00:38'),(2,'Approved','Manager',25,3,NULL,'Bosch','Bosch',NULL,'2020-12-31 01:37:02','2021-01-05 08:37:56'),(4,'Approved','Admin',3,NULL,NULL,'Black and Decker','Black and Decker',NULL,'2020-12-31 04:17:21','2020-12-31 04:17:21'),(5,'Approved','Admin',3,NULL,NULL,'Stanley','Stanley',NULL,'2021-01-05 17:09:11','2021-01-05 17:09:11'),(9,'Approved','Admin',3,NULL,NULL,'Dewalt Tools','Dewalt',NULL,'2021-02-25 16:39:18','2021-02-25 16:39:18'),(10,'Approved','Admin',3,NULL,NULL,'Makita','Makita',NULL,'2021-03-18 00:08:19','2021-03-18 00:08:19');
/*!40000 ALTER TABLE `tool_brands` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `toolkit_details`
--

DROP TABLE IF EXISTS `toolkit_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `toolkit_details` (
  `toolkit_detail_id` int(11) NOT NULL AUTO_INCREMENT,
  `toolkit_id` int(11) DEFAULT NULL,
  `deleted_by` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `code` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `serial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tool_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `brand` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tool_id` int(11) DEFAULT NULL,
  `tool_qty` int(11) DEFAULT NULL,
  `tool_state` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `length` int(11) DEFAULT NULL,
  `width` int(11) DEFAULT NULL,
  `weight` int(11) DEFAULT NULL,
  `size` int(11) DEFAULT NULL,
  `material` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `accessories` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `comments` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`toolkit_detail_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `toolkit_details`
--

LOCK TABLES `toolkit_details` WRITE;
/*!40000 ALTER TABLE `toolkit_details` DISABLE KEYS */;
INSERT INTO `toolkit_details` (`toolkit_detail_id`, `toolkit_id`, `deleted_by`, `updated_by`, `created_by`, `code`, `serial`, `tool_name`, `brand`, `tool_id`, `tool_qty`, `tool_state`, `length`, `width`, `weight`, `size`, `material`, `accessories`, `comments`, `deleted_at`, `created_at`, `updated_at`) VALUES (1,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,16,'Usable',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(2,2,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,16,'Usable',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(3,3,NULL,NULL,NULL,'jik900','DAG2000','5 Inch Dewalt Angle Grinder','Bosch',1,5,'Usable',0,0,0,0,'','','',NULL,NULL,NULL),(4,3,NULL,NULL,NULL,'Itel1300','Itel1000','Hand Wood Cutting Machine','Bosch',2,8,'Usable',0,0,0,0,'','','',NULL,NULL,NULL),(5,3,NULL,NULL,NULL,'','','Engineer\'s Hammer ','',0,1,'Usable',300,0,300,0,'Fibreglass Shaft','Magnetic Bit holder','New ',NULL,NULL,NULL),(6,3,NULL,NULL,NULL,'','','Angle Rench ','',0,99,'Usable',0,0,0,0,'','','',NULL,NULL,NULL);
/*!40000 ALTER TABLE `toolkit_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `toolkits`
--

DROP TABLE IF EXISTS `toolkits`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `toolkits` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `status` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_by_type` varchar(191) COLLATE utf8_unicode_ci NOT NULL,
  `warehouse_id` int(11) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `deleted_by` int(11) DEFAULT NULL,
  `name` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `toolkits`
--

LOCK TABLES `toolkits` WRITE;
/*!40000 ALTER TABLE `toolkits` DISABLE KEYS */;
INSERT INTO `toolkits` (`id`, `status`, `created_by_type`, `warehouse_id`, `created_by`, `updated_by`, `deleted_by`, `name`, `description`, `deleted_at`, `created_at`, `updated_at`) VALUES (1,'Approved','Admin',NULL,3,NULL,NULL,'Toolkit A','Toolkit A',NULL,'2021-03-17 23:39:42','2021-03-17 23:39:42'),(2,'Approved','Admin',10,3,NULL,NULL,'Toolkit B','Toolkit B',NULL,'2021-03-17 23:43:18','2021-03-17 23:47:06'),(3,'Approved','Admin',6,3,NULL,NULL,'Brown Trolley ','Bought from elite tools',NULL,'2021-03-23 11:03:46','2021-03-23 11:06:24');
/*!40000 ALTER TABLE `toolkits` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tools`
--

DROP TABLE IF EXISTS `tools`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tools` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_by_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `approved` int(11) NOT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `deleted_by` int(11) DEFAULT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `code` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `serial` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image_url` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `main_category_id` int(11) NOT NULL,
  `sub_category_id` int(11) NOT NULL,
  `unit` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `quantity` int(11) DEFAULT NULL,
  `min_quantity` int(11) DEFAULT NULL,
  `max_quantity` int(11) DEFAULT NULL,
  `state_id` int(11) NOT NULL,
  `brand_id` int(11) NOT NULL,
  `cost` int(11) DEFAULT NULL,
  `price` int(11) DEFAULT NULL,
  `purchase_detail` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `callibration` date DEFAULT NULL,
  `Authorize` tinyint(1) NOT NULL DEFAULT 0,
  `warranty` date DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tools`
--

LOCK TABLES `tools` WRITE;
/*!40000 ALTER TABLE `tools` DISABLE KEYS */;
INSERT INTO `tools` (`id`, `status`, `created_by_type`, `approved`, `created_by`, `updated_by`, `deleted_by`, `name`, `type`, `code`, `serial`, `image_url`, `main_category_id`, `sub_category_id`, `unit`, `quantity`, `min_quantity`, `max_quantity`, `state_id`, `brand_id`, `cost`, `price`, `purchase_detail`, `description`, `callibration`, `Authorize`, `warranty`, `deleted_at`, `created_at`, `updated_at`) VALUES (1,'Approved','Admin',1,3,NULL,NULL,'5 Inch Dewalt Angle Grinder','Tool','jik900','DAG2000','https://www.indiamart.com/proddetail/ss-hand-grinder-21406404830.html',2,8,'Pcs',10,10,20,5,2,NULL,NULL,NULL,'test',NULL,0,NULL,NULL,'2021-03-18 13:05:46','2021-03-18 13:05:46'),(2,'Approved','Admin',1,3,NULL,NULL,'Hand Wood Cutting Machine','Tool','Itel1300','Itel1000','https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRaAY8wR7BGGnQNVrpH9eai1AqM0-Unh8Q1sw&usqp=CAU',3,12,'Pcs',15,10,25,5,2,NULL,NULL,NULL,'Hand Wood Cutting Machine',NULL,0,NULL,NULL,'2021-03-18 13:07:08','2021-03-18 13:07:08');
/*!40000 ALTER TABLE `tools` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `toolstates`
--

DROP TABLE IF EXISTS `toolstates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `toolstates` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_by_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_by` int(11) unsigned DEFAULT NULL,
  `updated_by` int(11) unsigned DEFAULT NULL,
  `deleted_by` int(11) unsigned DEFAULT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `created_by` (`created_by`),
  KEY `updated_by` (`updated_by`),
  KEY `deleted_by` (`deleted_by`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `toolstates`
--

LOCK TABLES `toolstates` WRITE;
/*!40000 ALTER TABLE `toolstates` DISABLE KEYS */;
INSERT INTO `toolstates` (`id`, `status`, `created_by_type`, `created_by`, `updated_by`, `deleted_by`, `name`, `description`, `deleted_at`, `created_at`, `updated_at`) VALUES (1,'Approved','Admin',3,NULL,20,'state','lorem ipsum dolar sit amet','2020-12-30 22:00:01','2020-12-19 16:16:13','2020-12-30 22:00:01'),(4,'Approved','Admin',3,3,NULL,'Faulty','Faulty',NULL,'2020-12-31 04:16:41','2021-01-14 17:12:22'),(5,'Approved','Admin',3,NULL,NULL,'Usable','Usable',NULL,'2020-12-31 04:16:54','2020-12-31 04:16:54');
/*!40000 ALTER TABLE `toolstates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `transfer_toolkit_stocks`
--

DROP TABLE IF EXISTS `transfer_toolkit_stocks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `transfer_toolkit_stocks` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT 'Pending',
  `transfer_no` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `officer_id` int(11) DEFAULT NULL,
  `responsible_id` int(11) DEFAULT NULL,
  `created_by_type` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `deleted_by` int(11) DEFAULT NULL,
  `toolkit_id` int(11) DEFAULT NULL,
  `dest_warehouse_id` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `memo` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `job_card_id` int(11) DEFAULT NULL,
  `start_mileage` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `stop_mileage` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `vehicle` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `transfer_qty` int(11) DEFAULT NULL,
  `transfer_tool_kit_stock_by_user_type` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `transfer_to` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `transfer_by` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `project` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `site` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `expected` date DEFAULT NULL,
  `approved` tinyint(4) DEFAULT 0,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `job_card_id` (`job_card_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transfer_toolkit_stocks`
--

LOCK TABLES `transfer_toolkit_stocks` WRITE;
/*!40000 ALTER TABLE `transfer_toolkit_stocks` DISABLE KEYS */;
/*!40000 ALTER TABLE `transfer_toolkit_stocks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by_type` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `deleted_by` int(11) DEFAULT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password_status` int(11) NOT NULL DEFAULT 1,
  `is_login_first_time` tinyint(1) DEFAULT 0,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` (`id`, `status`, `created_by_type`, `created_by`, `updated_by`, `deleted_by`, `name`, `email`, `email_verified_at`, `password`, `password_status`, `is_login_first_time`, `remember_token`, `deleted_at`, `created_at`, `updated_at`) VALUES (3,'Approved','Admin',3,NULL,NULL,'Noman','admin@admin.com',NULL,'$2y$10$Ub8mWGPYxJC1gERRw4NqDeVkHmOA4dUTli20MCTvL/JFM0xs47r4a',1,1,'MwJ7PpVqKts2DNKnmXg3QeecXoCWTCT7gdu7H0r3GvY0EBRPm7RJ6PI68XWj',NULL,'2020-12-19 15:34:02','2020-12-19 15:34:02'),(25,'Approved','Admin',3,3,NULL,'Marrion','marrionwanjiru26@gmail.com',NULL,'$2y$10$TmPdsDEhuuKVlSliLlg.2uHP6EWBh3mJ9u2AMWtpm1y/dU877nXvm',1,1,NULL,NULL,'2021-01-01 04:19:50','2021-01-01 04:20:24'),(27,'Approved','Admin',3,NULL,NULL,'Murithi','henfreykim@gmail.com',NULL,'$2y$10$TmPdsDEhuuKVlSliLlg.2uHP6EWBh3mJ9u2AMWtpm1y/dU877nXvm',1,0,NULL,NULL,'2021-01-05 08:27:31','2021-01-05 08:27:31'),(28,'Approved','Admin',3,NULL,NULL,'Njume','kimearth.jr@gmail.com',NULL,'$2y$10$TmPdsDEhuuKVlSliLlg.2uHP6EWBh3mJ9u2AMWtpm1y/dU877nXvm',1,1,NULL,NULL,'2021-01-05 08:29:34','2021-01-05 08:29:34'),(32,'Approved','Admin',3,3,NULL,'Ali','1umarzahid028@gmail.com',NULL,'$2y$10$TmPdsDEhuuKVlSliLlg.2uHP6EWBh3mJ9u2AMWtpm1y/dU877nXvm',1,1,NULL,NULL,'2021-01-13 14:57:13','2021-01-13 21:15:57'),(33,'Approved','Admin',3,NULL,NULL,'umar028','umarzahid028@gmail.com',NULL,'$2y$10$CvbAFznJ0JFSVt0HP.wI1OJcoba.93Uto7ngjM48EV1Cs/xl2z24O',1,0,NULL,NULL,'2021-02-23 04:44:03','2021-02-23 04:44:03'),(34,'Approved','Admin',3,NULL,NULL,'Henfrey Murithi','henfrey@aprotec.co.ke',NULL,'$2y$10$vCeIWYaf1d2Wo5Dhjj5Q/uublIwFFpym7oZ8l9G1CXvE3uy6pQTdi',1,0,NULL,NULL,'2021-02-25 17:20:45','2021-02-25 17:20:45'),(35,'Approved','Admin',3,NULL,NULL,'John','henfreyk@gmail.com',NULL,'$2y$10$PjCH1TVKNj6hpmZRYk8nW.tJWbWgy6IFJVWv8l.odUjhTKgQ1fhXK',1,0,NULL,NULL,'2021-02-25 17:21:39','2021-02-25 17:21:39'),(36,'Approved','Admin',3,NULL,NULL,'Farah Naz','farahjokhio@gmail.com',NULL,'$2y$10$KPaewfaAW2kSTWrxlxWfNerKWFgI6yPxlh7EPU0YFGmjYy9EhRNwS',1,0,NULL,NULL,'2021-03-10 16:36:52','2021-03-10 16:36:52');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vehicle_bak`
--

DROP TABLE IF EXISTS `vehicle_bak`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vehicle_bak` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `status` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_by_type` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `deleted_by` int(11) DEFAULT NULL,
  `vehicle_licence` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `update_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vehicle_bak`
--

LOCK TABLES `vehicle_bak` WRITE;
/*!40000 ALTER TABLE `vehicle_bak` DISABLE KEYS */;
/*!40000 ALTER TABLE `vehicle_bak` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vehicles`
--

DROP TABLE IF EXISTS `vehicles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vehicles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `vehicle_licence` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vehicles`
--

LOCK TABLES `vehicles` WRITE;
/*!40000 ALTER TABLE `vehicles` DISABLE KEYS */;
INSERT INTO `vehicles` (`id`, `vehicle_licence`, `deleted_at`, `created_at`, `updated_at`) VALUES (1,'FG5688',NULL,'2021-01-26 16:36:22',NULL),(2,'FDE343',NULL,NULL,NULL),(3,'RTS767',NULL,NULL,NULL),(4,'FDE346',NULL,NULL,NULL),(5,'RTY768',NULL,NULL,NULL),(6,'TYS786',NULL,'2021-01-26 12:41:19','2021-01-26 12:41:19'),(7,'34534',NULL,'2021-02-13 13:48:07','2021-02-13 13:48:07'),(8,'34534',NULL,'2021-02-13 13:54:52','2021-02-13 13:54:52'),(9,'GB678',NULL,'2021-02-13 13:58:14','2021-02-13 13:58:14'),(10,'FF3242',NULL,'2021-02-23 10:23:15','2021-02-23 10:23:15'),(11,'DDD3343',NULL,'2021-02-23 10:48:27','2021-02-23 10:48:27'),(12,'Add45',NULL,'2021-02-23 18:11:36','2021-02-23 18:11:36'),(13,'KBC 100B',NULL,'2021-02-25 16:51:56','2021-02-25 16:51:56'),(14,NULL,NULL,'2021-02-26 09:21:33','2021-02-26 09:21:33'),(15,'Est nostrum in maxim',NULL,'2021-03-09 12:14:37','2021-03-09 12:14:37'),(16,'KUJ 800A',NULL,'2021-03-09 16:08:26','2021-03-09 16:08:26'),(17,'KCA 600K',NULL,'2021-03-10 16:09:57','2021-03-10 16:09:57'),(18,'KBU 555K',NULL,'2021-03-12 11:55:27','2021-03-12 11:55:27');
/*!40000 ALTER TABLE `vehicles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vendors`
--

DROP TABLE IF EXISTS `vendors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vendors` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `status` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_by_type` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `deleted_by` int(11) DEFAULT NULL,
  `name` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mobile_number` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vendors`
--

LOCK TABLES `vendors` WRITE;
/*!40000 ALTER TABLE `vendors` DISABLE KEYS */;
INSERT INTO `vendors` (`id`, `status`, `created_by_type`, `created_by`, `updated_by`, `deleted_by`, `name`, `email`, `mobile_number`, `description`, `deleted_at`, `created_at`, `updated_at`) VALUES (1,'Approved','Admin',3,3,NULL,'Supplier and sons Ltd','john@gmail.com','03011234567','New vendor',NULL,'2021-01-05 05:20:07','2021-03-15 20:48:57'),(2,'Approved','Admin',3,3,NULL,'Maruti Supplier','joemarutisupplier@gmail.com','070028763888','supplier pin P0909889887K',NULL,'2021-01-05 08:45:05','2021-01-14 17:46:09'),(5,'Approved','Admin',3,3,NULL,'Power Tool Suppliers LTD','newsupp@gmail.com','03011234567','New vendor',NULL,'2021-01-28 16:40:17','2021-03-15 20:47:44'),(6,'Approved','Admin',3,3,NULL,'Power Machinery Suppliers','demoumarzahid028@gmail.com','23456768979654','new supplier',NULL,'2021-02-23 10:47:25','2021-03-15 20:48:11');
/*!40000 ALTER TABLE `vendors` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `warehouses`
--

DROP TABLE IF EXISTS `warehouses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `warehouses` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_by_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `deleted_by` int(11) DEFAULT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `location_id` int(11) NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `warehouses`
--

LOCK TABLES `warehouses` WRITE;
/*!40000 ALTER TABLE `warehouses` DISABLE KEYS */;
INSERT INTO `warehouses` (`id`, `status`, `created_by_type`, `created_by`, `updated_by`, `deleted_by`, `name`, `description`, `location_id`, `deleted_at`, `created_at`, `updated_at`) VALUES (6,'Approved','Admin',3,3,NULL,'HQ-Warehouse','W1-HQ',7,NULL,'2020-12-31 04:05:10','2020-12-31 04:05:33'),(7,'Approved','Admin',3,NULL,NULL,'Kitengela - A','Kitengela - A',8,NULL,'2021-01-05 08:34:11','2021-01-05 08:34:11'),(9,'Approved','Admin',3,NULL,NULL,'Iko Briq Bin','Iko Briq Bin',9,NULL,'2021-01-05 08:35:21','2021-01-05 08:35:21'),(10,'Approved','Admin',3,NULL,NULL,'Kenapen Warehouse','Kenapen location',10,NULL,'2021-03-15 20:50:57','2021-03-15 20:50:57'),(11,'Approved','Admin',3,NULL,NULL,'Kapa Oil Refineries Warehouse','New warehouse',11,NULL,'2021-03-15 20:51:28','2021-03-15 20:51:28');
/*!40000 ALTER TABLE `warehouses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'faradjij_erp'
--

--
-- Dumping routines for database 'faradjij_erp'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-03-27  9:53:51
